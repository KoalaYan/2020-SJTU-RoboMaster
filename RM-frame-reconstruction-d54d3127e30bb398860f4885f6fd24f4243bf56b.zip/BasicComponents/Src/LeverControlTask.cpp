/**
  ******************************************************************************
  * @FileName			    LeverControlTask.cpp
  * @Description            Control the robot by the lever on the remote
  * @author                 Steve Young
  * @note
  ******************************************************************************
  *
  * Copyright (c) 2021 Team JiaoLong-ShanghaiJiaoTong University
  * All rights reserved.
  *
  ******************************************************************************
**/

#include "includes.h"

#define USE_CHASSIS_FOLLOW

void Remote::LeverControl() {
    static WorkState_e lastWorkState = NORMAL_STATE;
    if (workState <= 0) return;

    Chassis::chassis.SetVelocity(channel.rcol, channel.rrow, channel.lrow * 5);   //control car driving
	  
	  if (channel.lcol>300){
			__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_3,1500);    //use the clamp to hold the pipe
		}
		else{
			__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_3,0); 
		}

    if (workState == NORMAL_STATE) {
				Additional::additional.setTargetAngle(0);
    } 
		else if (workState == ADDITIONAL_STATE_ONE) {         //hang up 70mm
				Additional::additional.setTargetAngle(60);
    } 
		else if (workState == ADDITIONAL_STATE_TWO) {         //constantly rotate to 135mm height
				Additional::additional.setRotate();
    }
    lastWorkState = workState;
}
