# RM_frame2 更新记录

## version 1.0.1
@author 席望

@brief 文件整理与重新命名

@details \
1.将ITTask改名为CallbackAdministration \
2.源文件重新归类 \
3.新建CMake文件，用于CLion工程

@todo \
1.更新MDK工程配置 \
2.C与C++兼容性 \
3.唱歌跳舞部分难以编译，已经在CMakeList里面注释掉

@note \
非稳定版本

## version 1.0.9

@author 刘畅、席望、杨宸

@brief 拨杆控制整车运动

@todo \
1.键鼠控制完善（斜坡函数） \
2.要等电机回传数据后再进入NORMAL_STATE \
3.扭腰只扭一次 \

@note \
非稳定版本

