//
// Created by 92304 on 2020/10/4.
//

#include "../Inc/Additional.h"

#include "includes.h"

void Additional::Handle() {
    M2006.Handle();
}

void Additional::Reset() {
    M2006.Reset(CAN_TYPE_1, 0x202, 36,
                800.0, 0, 0.0, 1580.0, 1080.0, 1080.0, 1080.0,
                15.0, 0, 0.0, 10000.0, 5000.0, 10000.0, 10000.0);
}

void Additional::setTargetAngle(int16_t Angle) {
    M2006.targetAngle = Angle;
}

void Additional::setRotate() {
	for(;;){
		if (M2006.targetAngle>=360) M2006.targetAngle -=360;
    M2006.targetAngle +=2;
	}
}


Additional Additional::additional;